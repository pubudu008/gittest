package com.example.demo.models;

public enum Comment {

}
